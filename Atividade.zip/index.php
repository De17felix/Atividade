
<html lang="en">
<head>
  <title>Bootstrap </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="jumbotron text-center">
  <h1>Minha página</h1>
  <p>Denise Felix Ferreira!</p> 
</div>
  
<div class="container">
  <div class="row">
    <div class="col-sm-4">
      <h3>Informações pessoais</h3>
      <p>Meu nome é Denise, tenho 18 anos ...</p>
      <p>Sou de São Paulo - Guarulhos</p>
    </div>
    <div class="col-sm-4">
      <h3>Escolaridade</h3>
      <p>Estudo no IFSP - Instituto Federal de São Paulo.</p>
      <p>Estou cursando Técnico em informática para internet integrado ao Ensino médio...</p>
    </div>
    <div class="col-sm-4">
      <h3>Vida social</h3>        
      <p>Adoro fazer compras, ir ao shopping, tirar fotos e até me arrisco na cozinha fazendo bolos e gosto dos meus livros.</p>
      <p>Gosto de música sei tocar órgão e ler partituras.Isso me faz muito bem.Tenho duas irmãs e uma sobrinha que eu gosto muito.</p>
    </div>
  </div>
</div>

</body>
</html>
